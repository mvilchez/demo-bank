package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.AccountEntry;
import io.swagger.model.Balance;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OverallAccountPosition
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2022-06-15T14:36:24.629Z")


public class OverallAccountPosition   {
  @JsonProperty("balance")
  private Balance balance = null;

  @JsonProperty("accountId")
  private String accountId = null;

  @JsonProperty("date")
  private OffsetDateTime date = null;

  @JsonProperty("movements")
  @Valid
  private List<AccountEntry> movements = null;

  public OverallAccountPosition balance(Balance balance) {
    this.balance = balance;
    return this;
  }

  /**
   * Get balance
   * @return balance
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Balance getBalance() {
    return balance;
  }

  public void setBalance(Balance balance) {
    this.balance = balance;
  }

  public OverallAccountPosition accountId(String accountId) {
    this.accountId = accountId;
    return this;
  }

  /**
   * Get accountId
   * @return accountId
  **/
  @ApiModelProperty(value = "")


  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public OverallAccountPosition date(OffsetDateTime date) {
    this.date = date;
    return this;
  }

  /**
   * Get date
   * @return date
  **/
  @ApiModelProperty(value = "")

  @Valid

  public OffsetDateTime getDate() {
    return date;
  }

  public void setDate(OffsetDateTime date) {
    this.date = date;
  }

  public OverallAccountPosition movements(List<AccountEntry> movements) {
    this.movements = movements;
    return this;
  }

  public OverallAccountPosition addMovementsItem(AccountEntry movementsItem) {
    if (this.movements == null) {
      this.movements = new ArrayList<AccountEntry>();
    }
    this.movements.add(movementsItem);
    return this;
  }

  /**
   * array of account movements
   * @return movements
  **/
  @ApiModelProperty(value = "array of account movements")

  @Valid

  public List<AccountEntry> getMovements() {
    return movements;
  }

  public void setMovements(List<AccountEntry> movements) {
    this.movements = movements;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OverallAccountPosition overallAccountPosition = (OverallAccountPosition) o;
    return Objects.equals(this.balance, overallAccountPosition.balance) &&
        Objects.equals(this.accountId, overallAccountPosition.accountId) &&
        Objects.equals(this.date, overallAccountPosition.date) &&
        Objects.equals(this.movements, overallAccountPosition.movements);
  }

  @Override
  public int hashCode() {
    return Objects.hash(balance, accountId, date, movements);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OverallAccountPosition {\n");
    
    sb.append("    balance: ").append(toIndentedString(balance)).append("\n");
    sb.append("    accountId: ").append(toIndentedString(accountId)).append("\n");
    sb.append("    date: ").append(toIndentedString(date)).append("\n");
    sb.append("    movements: ").append(toIndentedString(movements)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

