package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.User;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Account
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2022-06-15T14:36:24.629Z")


public class Account   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("accountNumberIban")
  private String accountNumberIban = null;

  @JsonProperty("accountNumberCCC")
  private String accountNumberCCC = null;

  @JsonProperty("holder")
  private User holder = null;

  public Account id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Account id
   * @return id
  **/
  @ApiModelProperty(value = "Account id")


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Account accountNumberIban(String accountNumberIban) {
    this.accountNumberIban = accountNumberIban;
    return this;
  }

  /**
   * International Banking Account Number
   * @return accountNumberIban
  **/
  @ApiModelProperty(value = "International Banking Account Number")


  public String getAccountNumberIban() {
    return accountNumberIban;
  }

  public void setAccountNumberIban(String accountNumberIban) {
    this.accountNumberIban = accountNumberIban;
  }

  public Account accountNumberCCC(String accountNumberCCC) {
    this.accountNumberCCC = accountNumberCCC;
    return this;
  }

  /**
   * Spain Banking Account Number
   * @return accountNumberCCC
  **/
  @ApiModelProperty(value = "Spain Banking Account Number")


  public String getAccountNumberCCC() {
    return accountNumberCCC;
  }

  public void setAccountNumberCCC(String accountNumberCCC) {
    this.accountNumberCCC = accountNumberCCC;
  }

  public Account holder(User holder) {
    this.holder = holder;
    return this;
  }

  /**
   * Get holder
   * @return holder
  **/
  @ApiModelProperty(value = "")

  @Valid

  public User getHolder() {
    return holder;
  }

  public void setHolder(User holder) {
    this.holder = holder;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Account account = (Account) o;
    return Objects.equals(this.id, account.id) &&
        Objects.equals(this.accountNumberIban, account.accountNumberIban) &&
        Objects.equals(this.accountNumberCCC, account.accountNumberCCC) &&
        Objects.equals(this.holder, account.holder);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, accountNumberIban, accountNumberCCC, holder);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Account {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    accountNumberIban: ").append(toIndentedString(accountNumberIban)).append("\n");
    sb.append("    accountNumberCCC: ").append(toIndentedString(accountNumberCCC)).append("\n");
    sb.append("    holder: ").append(toIndentedString(holder)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

